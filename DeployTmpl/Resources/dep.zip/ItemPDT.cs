using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.IO;

namespace Install
{
	public class ItemPDT
	{
        public void InstCln(string Svr, string TarPath, string WsPath, string XlsPath, string WsUrl, string newNS, Action<int, string> progress)
        {
            throw new NotImplementedException("features not available");
        }
        public void InstRul(string TarPath, string newNS, Action<int, string> progress)
        {
            throw new NotImplementedException("features not available");
        }
        public void InstSysM(string Svr, string Usr, string Pwd, string newNS, Action<int, string> progress, string serverVer, string dbPath, string encKey, string AppUsr, string AppPwd, bool bIntegratedSecurity)
        {
            throw new NotImplementedException("features not available");
        }
        public void InstSysS(string Svr, string Usr, string Pwd, string newNS, Action<int, string> progress, string serverVer, string dbPath, string encKey, string AppUsr, string AppPwd, bool bIntegratedSecurity)
        {
            throw new NotImplementedException("features not available");
        }
        public void InstAppM(string Svr, string Usr, string Pwd, string newNS, Action<int, string> progress, string serverVer, string dbPath, string encKey, string AppUsr, string AppPwd, bool bIntegratedSecurity)
        {
            throw new NotImplementedException("features not available");
        }
        public void InstAppS(string Svr, string Usr, string Pwd, string newNS, Action<int, string> progress, string serverVer, string dbPath, string encKey, string AppUsr, string AppPwd, bool bIntegratedSecurity)
        {
            throw new NotImplementedException("features not available");
        }
        public void InstDesM(string Svr, string Usr, string Pwd, string newNS, Action<int, string> progress, string serverVer, string dbPath, string encKey, string AppUsr, string AppPwd, bool bIntegratedSecurity)
        {
            throw new NotImplementedException("features not available");
        }
        public void InstDesS(string Svr, string Usr, string Pwd, string newNS, Action<int, string> progress, string serverVer, string dbPath, string encKey, string AppUsr, string AppPwd, bool bIntegratedSecurity)
        {
            throw new NotImplementedException("features not available");
        }
        public void ApplyDesChg(string DbProvider, string Svr, string Usr, string Pwd, string newNS, string clientTierPath, string ruleTierPath, string WsTierPath, Action<int, string> progress, bool bIntegratedSecurity)
        {
            throw new NotImplementedException("features not available");
        }
        public void ApplyAppChg(string DbProvider, string Svr, string Usr, string Pwd, string newNS, string clientTierPath, string ruleTierPath, string WsTierPath, Action<int, string> progress, bool bIntegratedSecurity)
        {
            throw new NotImplementedException("features not available");
        }
    }
}
