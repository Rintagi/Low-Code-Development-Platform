namespace ZZ.UsrRules
{
	using System;
	using System.Data;
	using System.Web.UI;
	using System.Web.UI.WebControls;
	using System.ComponentModel;
	
	// Independent user rules.
	public class UsrRule
	{
	}
}