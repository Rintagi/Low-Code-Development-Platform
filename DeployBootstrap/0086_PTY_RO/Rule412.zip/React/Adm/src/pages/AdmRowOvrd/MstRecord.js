
import React, { Component } from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { Prompt, Redirect } from 'react-router';
import { Button, Row, Col, ButtonToolbar, ButtonGroup, DropdownItem, DropdownMenu, DropdownToggle, UncontrolledDropdown, Nav, NavItem, NavLink } from 'reactstrap';
import { Formik, Field, Form } from 'formik';
import DocumentTitle from 'react-document-title';
import classNames from 'classnames';
import LoadingIcon from 'mdi-react/LoadingIcon';
import CheckIcon from 'mdi-react/CheckIcon';
import DatePicker from '../../components/custom/DatePicker';
import NaviBar from '../../components/custom/NaviBar';
import DropdownField from '../../components/custom/DropdownField';
import AutoCompleteField from '../../components/custom/AutoCompleteField';
import RintagiScreen from '../../components/custom/Screen';
import ModalDialog from '../../components/custom/ModalDialog';
import { showNotification } from '../../redux/Notification';
import { registerBlocker, unregisterBlocker } from '../../helpers/navigation'
import { isEmptyId, getAddDtlPath, getAddMstPath, getEditDtlPath, getEditMstPath, getNaviPath, getDefaultPath } from '../../helpers/utils'
import { toMoney, toLocalAmountFormat, toLocalDateFormat, toDate, strFormat } from '../../helpers/formatter';
import { setTitle, setSpinner } from '../../redux/Global';
import { RememberCurrent, GetCurrent } from '../../redux/Persist'
import { getNaviBar } from './index';
import AdmRowOvrdReduxObj, { ShowMstFilterApplied } from '../../redux/AdmRowOvrd';
import Skeleton from 'react-skeleton-loader';
import ControlledPopover from '../../components/custom/ControlledPopover';

class MstRecord extends RintagiScreen {
  constructor(props) {
    super(props);
    this.GetReduxState = ()=> (this.props.AdmRowOvrd || {});
    this.blocker = null;
    this.titleSet = false;
    this.MstKeyColumnName = 'RowOvrdId238';
    this.SystemName = 'FintruX';
    this.confirmUnload = this.confirmUnload.bind(this);
    this.hasChangedContent = false;
    this.setDirtyFlag = this.setDirtyFlag.bind(this);
    this.AutoCompleteFilterBy = (option, props) => { return true };
    this.OnModalReturn = this.OnModalReturn.bind(this);
    this.ValidatePage = this.ValidatePage.bind(this);
    this.SavePage = this.SavePage.bind(this);
    this.FieldChange = this.FieldChange.bind(this);
    this.DateChange = this.DateChange.bind(this);
    this.DropdownChange = this.DropdownChange.bind(this);
    this.mobileView = window.matchMedia('(max-width: 1200px)');
    this.mediaqueryresponse = this.mediaqueryresponse.bind(this);
    this.SubmitForm = ((submitForm, options = {}) => {
      const _this = this;
      return (evt) => {
        submitForm();
      }
    }
    );
    this.state = {
      submitting: false,
      ScreenButton: null,
      key: '',
      Buttons: {},
      ModalColor: '',
      ModalTitle: '',
      ModalMsg: '',
      ModalOpen: false,
      ModalSuccess: null,
      ModalCancel: null,
      isMobile: false,
    }
    if (!this.props.suppressLoadPage && this.props.history) {
      RememberCurrent('LastAppUrl', (this.props.history || {}).location, true);
    }

    if (!this.props.suppressLoadPage) {
      this.props.setSpinner(true);
    }
  }

  mediaqueryresponse(value) {
    if (value.matches) { // if media query matches
      this.setState({ isMobile: true });
    }
    else {
      this.setState({ isMobile: false });
    }
  }

ScreenId238InputChange() { const _this = this; return function (name, v) {const filterBy = ''; _this.props.SearchScreenId238(v, filterBy);}}
ReportId238InputChange() { const _this = this; return function (name, v) {const filterBy = ''; _this.props.SearchReportId238(v, filterBy);}}/* ReactRule: Master Record Custom Function */
/* ReactRule End: Master Record Custom Function */

  /* form related input handling */
//  PostToAp({ submitForm, ScreenButton, naviBar, redirectTo, onSuccess }) {
//    return function (evt) {
//      this.OnClickColumeName = 'PostToAp';
//      submitForm();
//      evt.preventDefault();
//    }.bind(this);
//  }

  ValidatePage(values) {
    const errors = {};
    const columnLabel = (this.props.AdmRowOvrd || {}).ColumnLabel || {};
    /* standard field validation */
if (isEmptyId((values.cRowAuthId238 || {}).value)) { errors.cRowAuthId238 = (columnLabel.RowAuthId238 || {}).ErrMessage;}
if (isEmptyId((values.cAllowSel238 || {}).value)) { errors.cAllowSel238 = (columnLabel.AllowSel238 || {}).ErrMessage;}
    return errors;
  }

  SavePage(values, { setSubmitting, setErrors, resetForm, setFieldValue, setValues }) {
    const errors = [];
    const currMst = (this.props.AdmRowOvrd || {}).Mst || {};
/* ReactRule: Master Record Save */
/* ReactRule End: Master Record Save */

// No need to generate this, put this in the webrule
//    if ((+(currMst.TrxTotal64)) === 0 && (this.ScreenButton || {}).buttonType === 'SaveClose') {
//      errors.push('Please add at least one expense.');
//    } else if ((this.ScreenButton || {}).buttonType === 'Save' && values.cTrxNote64 !== 'ENTER-PURPOSE-OF-THIS-EXPENSE') {
//      // errors.push('Please do not change the Memo on Chq if Save Only');
//      // setFieldValue('cTrxNote64', 'ENTER-PURPOSE-OF-THIS-EXPENSE');
//    } else if ((this.ScreenButton || {}).buttonType === 'SaveClose' && values.cTrxNote64 === 'ENTER-PURPOSE-OF-THIS-EXPENSE') {
//      errors.push('Please change the Memo on Chq if Save & Pay Me');
//    }
    if (errors.length > 0) {
      this.props.showNotification('E', { message: errors[0] });
      setSubmitting(false);
    }
    else {
      const { ScreenButton, OnClickColumeName } = this;
      this.setState({submittedOn: Date.now(), submitting: true, setSubmitting: setSubmitting, key: currMst.key, ScreenButton: ScreenButton, OnClickColumeName: OnClickColumeName });
      this.ScreenButton = null;
      this.OnClickColumeName = null;
      this.props.SavePage(
        this.props.AdmRowOvrd,
        {
RowOvrdId238: values.cRowOvrdId238|| '',
ScreenId238: (values.cScreenId238|| {}).value || '',
ReportId238: (values.cReportId238|| {}).value || '',
RowAuthId238: (values.cRowAuthId238|| {}).value || '',
AllowSel238: (values.cAllowSel238|| {}).value || '',
AllowAdd238: values.cAllowAdd238 ? 'Y' : 'N',
AllowUpd238: values.cAllowUpd238 ? 'Y' : 'N',
AllowDel238: values.cAllowDel238 ? 'Y' : 'N',
        },
        [],
        {
          persist: true,
          ScreenButton: (ScreenButton || {}).buttonType,
          OnClickColumeName: OnClickColumeName,
        }
      );
    }
  }
  /* end of form related handling functions */

  /* standard screen button actions */
  SaveMst({ submitForm, ScreenButton }) {
    return function (evt) {
      this.ScreenButton = ScreenButton;
      submitForm();
    }.bind(this);
  }
  SaveCloseMst({ submitForm, ScreenButton, naviBar, redirectTo, onSuccess }) {
    return function (evt) {
      this.ScreenButton = ScreenButton;
      submitForm();
    }.bind(this);
  }
  NewSaveMst({ submitForm, ScreenButton }) {
    return function (evt) {
      this.ScreenButton = ScreenButton;
      submitForm();
    }.bind(this);
  }
  CopyHdr({ ScreenButton, mst, mstId, useMobileView }) {
    const AdmRowOvrdState = this.props.AdmRowOvrd || {};
    const auxSystemLabels = AdmRowOvrdState.SystemLabel || {};
    return function (evt) {
      evt.preventDefault();
      const fromMstId = mstId || (mst || {}).RowOvrdId238;
      const copyFn = () => {
        if (fromMstId) {
          this.props.AddMst(fromMstId, 'Mst', 0);
          /* this is application specific rule as the Posted flag needs to be reset */
          this.props.AdmRowOvrd.Mst.Posted64 = 'N';
          if (useMobileView) {
            const naviBar = getNaviBar('Mst', {}, {}, this.props.AdmRowOvrd.Label);
            this.props.history.push(getEditMstPath(getNaviPath(naviBar, 'Mst', '/'), '_'));
          }
          else {
            if (this.props.onCopy) this.props.onCopy();
          }
        }
        else {
          this.setState({ ModalOpen: true, ModalColor: 'warning', ModalTitle: auxSystemLabels.UnsavedPageTitle || '', ModalMsg: auxSystemLabels.UnsavedPageMsg || '' });
        }
      }
      if (!this.hasChangedContent) copyFn();
      else this.setState({ ModalOpen: true, ModalSuccess: copyFn, ModalColor: 'warning', ModalTitle: auxSystemLabels.UnsavedPageTitle || '', ModalMsg: auxSystemLabels.UnsavedPageMsg || '' });
    }.bind(this);
  }
  DelMst({ naviBar, ScreenButton, mst, mstId }) {
    const AdmRowOvrdState = this.props.AdmRowOvrd || {};
    const auxSystemLabels = AdmRowOvrdState.SystemLabel || {};
    return function (evt) {
      evt.preventDefault();
      const deleteFn = () => {
        const fromMstId = mstId || mst.RowOvrdId238;
        this.props.DelMst(this.props.AdmRowOvrd, fromMstId);
      };
      this.setState({ ModalOpen: true, ModalSuccess: deleteFn, ModalColor: 'danger', ModalTitle: auxSystemLabels.WarningTitle || '', ModalMsg: auxSystemLabels.DeletePageMsg || '' });
    }.bind(this);
  }
  /* end of screen button action */

  /* react related stuff */
  static getDerivedStateFromProps(nextProps, prevState) {
    const nextReduxScreenState = nextProps.AdmRowOvrd || {};
    const buttons = nextReduxScreenState.Buttons || {};
    const revisedButtonDef = super.GetScreenButtonDef(buttons, 'Mst', prevState);
    const currentKey = nextReduxScreenState.key;
    const waiting = nextReduxScreenState.page_saving || nextReduxScreenState.page_loading;
    let revisedState = {};
    if (revisedButtonDef) revisedState.Buttons = revisedButtonDef;

    if (prevState.submitting && !waiting && nextReduxScreenState.submittedOn > prevState.submittedOn) {
      prevState.setSubmitting(false);
    }

    return revisedState;
  }

  confirmUnload(message, callback) {
    const AdmRowOvrdState = this.props.AdmRowOvrd || {};
    const auxSystemLabels = AdmRowOvrdState.SystemLabel || {};
    const confirm = () => {
      callback(true);
    }
    const cancel = () => {
      callback(false);
    }
    this.setState({ ModalOpen: true, ModalSuccess: confirm, ModalCancel: cancel, ModalColor: 'warning', ModalTitle: auxSystemLabels.UnsavedPageTitle || '', ModalMsg: message });
  }

  setDirtyFlag(dirty) {
    /* this is called during rendering but has side-effect, undesirable but only way to pass formik dirty flag around */
    if (dirty) {
      if (this.blocker) unregisterBlocker(this.blocker);
      this.blocker = this.confirmUnload;
      registerBlocker(this.confirmUnload);
    }
    else {
      if (this.blocker) unregisterBlocker(this.blocker);
      this.blocker = null;
    }
    if (this.props.updateChangedState) this.props.updateChangedState(dirty);
    this.SetCurrentRecordState(dirty);
    return true;
  }

  componentDidMount() {
    this.mediaqueryresponse(this.mobileView);
    this.mobileView.addListener(this.mediaqueryresponse) // attach listener function to listen in on state changes
    const isMobileView = this.state.isMobile;
    const useMobileView = (isMobileView && !(this.props.user || {}).desktopView);
    const suppressLoadPage = this.props.suppressLoadPage;
    if (!suppressLoadPage) {
      const { mstId } = { ...this.props.match.params };
      if (!(this.props.AdmRowOvrd || {}).AuthCol || true) {
        this.props.LoadPage('Mst', { mstId: mstId || '_' });
      }
    }
    else {
      return;
    }
  }

  componentDidUpdate(prevprops, prevstates) {
    const currReduxScreenState = this.props.AdmRowOvrd || {};

    if (!this.props.suppressLoadPage) {
      if (!currReduxScreenState.page_loading && this.props.global.pageSpinner) {
        const _this = this;
        setTimeout(() => _this.props.setSpinner(false), 500);
      }
    }

    const currMst = currReduxScreenState.Mst || {};
    this.SetPageTitle(currReduxScreenState);
    if (prevstates.key !== currMst.key) {
      if ((prevstates.ScreenButton || {}).buttonType === 'SaveClose') {
        const currDtl = currReduxScreenState.EditDtl || {};
        const dtlList = (currReduxScreenState.DtlList || {}).data || [];
        const naviBar = getNaviBar('Mst', currMst, currDtl, currReduxScreenState.Label);
        const searchListPath = getDefaultPath(getNaviPath(naviBar, 'MstList', '/'))
        this.props.history.push(searchListPath);
      }
    }
  }

  componentWillUnmount() {
    if (this.blocker) {
      unregisterBlocker(this.blocker);
      this.blocker = null;
    }
    this.mobileView.removeListener(this.mediaqueryresponse);
  }


  render() {
    const AdmRowOvrdState = this.props.AdmRowOvrd || {};

    if (AdmRowOvrdState.access_denied) {
      return <Redirect to='/error' />;
    }

    const screenHlp = AdmRowOvrdState.ScreenHlp;

    // Labels
    const siteTitle = (this.props.global || {}).pageTitle || '';
    const MasterRecTitle = ((screenHlp || {}).MasterRecTitle || '');
    const MasterRecSubtitle = ((screenHlp || {}).MasterRecSubtitle || '');

    const screenButtons = AdmRowOvrdReduxObj.GetScreenButtons(AdmRowOvrdState) || {};
    const itemList = AdmRowOvrdState.Dtl || [];
    const auxLabels = AdmRowOvrdState.Label || {};
    const auxSystemLabels = AdmRowOvrdState.SystemLabel || {};

    const columnLabel = AdmRowOvrdState.ColumnLabel || {};
    const authCol = this.GetAuthCol(AdmRowOvrdState);
    const authRow = (AdmRowOvrdState.AuthRow || [])[0] || {};
    const currMst = ((this.props.AdmRowOvrd || {}).Mst || {});
    const currDtl = ((this.props.AdmRowOvrd || {}).EditDtl || {});
    const naviBar = getNaviBar('Mst', currMst, currDtl, screenButtons).filter(v => ((v.type !== 'Dtl' && v.type !== 'DtlList') || currMst.RowOvrdId238));
    const selectList = AdmRowOvrdReduxObj.SearchListToSelectList(AdmRowOvrdState);
    const selectedMst = (selectList || []).filter(v => v.isSelected)[0] || {};
const RowOvrdId238 = currMst.RowOvrdId238;
const ScreenId238List = AdmRowOvrdReduxObj.ScreenDdlSelectors.ScreenId238(AdmRowOvrdState);
const ScreenId238 = currMst.ScreenId238;
const ReportId238List = AdmRowOvrdReduxObj.ScreenDdlSelectors.ReportId238(AdmRowOvrdState);
const ReportId238 = currMst.ReportId238;
const RowAuthId238List = AdmRowOvrdReduxObj.ScreenDdlSelectors.RowAuthId238(AdmRowOvrdState);
const RowAuthId238 = currMst.RowAuthId238;
const AllowSel238List = AdmRowOvrdReduxObj.ScreenDdlSelectors.AllowSel238(AdmRowOvrdState);
const AllowSel238 = currMst.AllowSel238;
const AllowAdd238 = currMst.AllowAdd238;
const AllowUpd238 = currMst.AllowUpd238;
const AllowDel238 = currMst.AllowDel238;

    const { dropdownMenuButtonList, bottomButtonList, hasDropdownMenuButton, hasBottomButton, hasRowButton } = this.state.Buttons;
    const hasActableButtons = hasBottomButton || hasRowButton || hasDropdownMenuButton;

    const isMobileView = this.state.isMobile;
    const useMobileView = (isMobileView && !(this.props.user || {}).desktopView);
/* ReactRule: Master Render */
/* ReactRule End: Master Render */

    return (
      <DocumentTitle title={siteTitle}>
        <div>
          <ModalDialog color={this.state.ModalColor} title={this.state.ModalTitle} onChange={this.OnModalReturn} ModalOpen={this.state.ModalOpen} message={this.state.ModalMsg} />
          <div className='account'>
            <div className='account__wrapper account-col'>
              <div className='account__card shadow-box rad-4'>
                {/* {!useMobileView && this.constructor.ShowSpinner(AdmRowOvrdState) && <div className='panel__refresh'></div>} */}
                {useMobileView && <div className='tabs tabs--justify tabs--bordered-bottom'>
                  <div className='tabs__wrap'>
                    <NaviBar history={this.props.history} navi={naviBar} />
                  </div>
                </div>}
                <p className='project-title-mobile mb-10'>{siteTitle.substring(0, document.title.indexOf('-') - 1)}</p>
                <Formik
                  initialValues={{
cRowOvrdId238: RowOvrdId238 || '',
cScreenId238: ScreenId238List.filter(obj => { return obj.key === ScreenId238 })[0],
cReportId238: ReportId238List.filter(obj => { return obj.key === ReportId238 })[0],
cRowAuthId238: RowAuthId238List.filter(obj => { return obj.key === RowAuthId238 })[0],
cAllowSel238: AllowSel238List.filter(obj => { return obj.key === AllowSel238 })[0],
cAllowAdd238: AllowAdd238 === 'Y',
cAllowUpd238: AllowUpd238 === 'Y',
cAllowDel238: AllowDel238 === 'Y',
                  }}
                  validate={this.ValidatePage}
                  onSubmit={this.SavePage}
                  key={currMst.key}
                  render={({
                    values,
                    errors,
                    touched,
                    isSubmitting,
                    dirty,
                    setFieldValue,
                    setFieldTouched,
                    handleChange,
                    submitForm
                  }) => (
                      <div>
                        {this.setDirtyFlag(dirty) &&
                          <Prompt
                            when={dirty}
                            message={auxSystemLabels.UnsavedPageMsg || ''}
                          />
                        }
                        <div className='account__head'>
                          <Row>
                            <Col xs={useMobileView ? 9 : 8}>
                              <h3 className='account__title'>{MasterRecTitle}</h3>
                              <h4 className='account__subhead subhead'>{MasterRecSubtitle}</h4>
                            </Col>
                            <Col xs={useMobileView ? 3 : 4}>
                              <ButtonToolbar className='f-right'>
                                {this.constructor.ShowSpinner(AdmRowOvrdState) && <Skeleton height='40px' /> ||
                                  <UncontrolledDropdown>
                                    <ButtonGroup className='btn-group--icons'>
                                      <i className={dirty ? 'fa fa-exclamation exclamation-icon' : ''}></i>
                                      {
                                        dropdownMenuButtonList.filter(v => !v.expose && !this.ActionSuppressed(authRow, v.buttonType, (currMst || {}).RowOvrdId238)).length > 0 &&
                                        <DropdownToggle className='mw-50' outline>
                                          <i className='fa fa-ellipsis-h icon-holder'></i>
                                          {!useMobileView && <p className='action-menu-label'>{(screenButtons.More || {}).label}</p>}
                                        </DropdownToggle>
                                      }
                                    </ButtonGroup>
                                    {
                                      dropdownMenuButtonList.filter(v => !v.expose).length > 0 &&
                                      <DropdownMenu right className={`dropdown__menu dropdown-options`}>
                                        {
                                          dropdownMenuButtonList.filter(v => !v.expose).map(v => {
                                            if (this.ActionSuppressed(authRow, v.buttonType, (currMst || {}).RowOvrdId238)) return null;
                                            return (
                                              <DropdownItem key={v.tid || v.order} onClick={this.ScreenButtonAction[v.buttonType]({ naviBar, submitForm, ScreenButton: v, mst: currMst, dtl: currDtl, useMobileView })} className={`${v.className}`}><i className={`${v.iconClassName} mr-10`}></i>{v.label}</DropdownItem>)
                                          })
                                        }
                                      </DropdownMenu>
                                    }
                                  </UncontrolledDropdown>
                                }
                              </ButtonToolbar>
                            </Col>
                          </Row>
                        </div>
                        <Form className='form'> {/* this line equals to <form className='form' onSubmit={handleSubmit} */}

                          <div className='w-100'>
                            <Row>
            {(authCol.RowOvrdId238 || {}).visible &&
 <Col lg={6} xl={6}>
<div className='form__form-group'>
{(true && this.constructor.ShowSpinner(AdmRowOvrdState)) && <Skeleton height='20px' /> ||
<label className='form__form-group-label'>{(columnLabel.RowOvrdId238 || {}).ColumnHeader} {(columnLabel.RowOvrdId238 || {}).ToolTip && 
 (<ControlledPopover id={(columnLabel.RowOvrdId238 || {}).ColumnName} className='sticky-icon pt-0 lh-23' message= {(columnLabel.RowOvrdId238 || {}).ToolTip} />
)}
</label>
}
{(true && this.constructor.ShowSpinner(AdmRowOvrdState)) && <Skeleton height='36px' /> ||
<div className='form__form-group-field'>
<Field
type='text'
name='cRowOvrdId238'
disabled = {(authCol.RowOvrdId238 || {}).readonly ? 'disabled': '' }/>
</div>
}
{errors.cRowOvrdId238 && touched.cRowOvrdId238 && <span className='form__form-group-error'>{errors.cRowOvrdId238}</span>}
</div>
</Col>
}
{(authCol.ScreenId238 || {}).visible &&
 <Col lg={6} xl={6}>
<div className='form__form-group'>
{(true && this.constructor.ShowSpinner(AdmRowOvrdState)) && <Skeleton height='20px' /> ||
<label className='form__form-group-label'>{(columnLabel.ScreenId238 || {}).ColumnHeader} {(columnLabel.ScreenId238 || {}).ToolTip && 
 (<ControlledPopover id={(columnLabel.ScreenId238 || {}).ColumnName} className='sticky-icon pt-0 lh-23' message= {(columnLabel.ScreenId238 || {}).ToolTip} />
)}
</label>
}
{(true && this.constructor.ShowSpinner(AdmRowOvrdState)) && <Skeleton height='36px' /> ||
<div className='form__form-group-field'>
<AutoCompleteField
name='cScreenId238'
onChange={this.FieldChange(setFieldValue, setFieldTouched, 'cScreenId238', false)}
onBlur={this.FieldChange(setFieldValue, setFieldTouched, 'cScreenId238', true)}
onInputChange={this.ScreenId238InputChange()}
value={values.cScreenId238}
defaultSelected={ScreenId238List.filter(obj => { return obj.key === ScreenId238 })}
options={ScreenId238List}
filterBy={this.AutoCompleteFilterBy}
disabled = {(authCol.ScreenId238 || {}).readonly ? true: false }/>
</div>
}
{errors.cScreenId238 && touched.cScreenId238 && <span className='form__form-group-error'>{errors.cScreenId238}</span>}
</div>
</Col>
}
{(authCol.ReportId238 || {}).visible &&
 <Col lg={6} xl={6}>
<div className='form__form-group'>
{(true && this.constructor.ShowSpinner(AdmRowOvrdState)) && <Skeleton height='20px' /> ||
<label className='form__form-group-label'>{(columnLabel.ReportId238 || {}).ColumnHeader} {(columnLabel.ReportId238 || {}).ToolTip && 
 (<ControlledPopover id={(columnLabel.ReportId238 || {}).ColumnName} className='sticky-icon pt-0 lh-23' message= {(columnLabel.ReportId238 || {}).ToolTip} />
)}
</label>
}
{(true && this.constructor.ShowSpinner(AdmRowOvrdState)) && <Skeleton height='36px' /> ||
<div className='form__form-group-field'>
<AutoCompleteField
name='cReportId238'
onChange={this.FieldChange(setFieldValue, setFieldTouched, 'cReportId238', false)}
onBlur={this.FieldChange(setFieldValue, setFieldTouched, 'cReportId238', true)}
onInputChange={this.ReportId238InputChange()}
value={values.cReportId238}
defaultSelected={ReportId238List.filter(obj => { return obj.key === ReportId238 })}
options={ReportId238List}
filterBy={this.AutoCompleteFilterBy}
disabled = {(authCol.ReportId238 || {}).readonly ? true: false }/>
</div>
}
{errors.cReportId238 && touched.cReportId238 && <span className='form__form-group-error'>{errors.cReportId238}</span>}
</div>
</Col>
}
{(authCol.RowAuthId238 || {}).visible &&
 <Col lg={6} xl={6}>
<div className='form__form-group'>
{(true && this.constructor.ShowSpinner(AdmRowOvrdState)) && <Skeleton height='20px' /> ||
<label className='form__form-group-label'>{(columnLabel.RowAuthId238 || {}).ColumnHeader} <span className='text-danger'>*</span>{(columnLabel.RowAuthId238 || {}).ToolTip && 
 (<ControlledPopover id={(columnLabel.RowAuthId238 || {}).ColumnName} className='sticky-icon pt-0 lh-23' message= {(columnLabel.RowAuthId238 || {}).ToolTip} />
)}
</label>
}
{(true && this.constructor.ShowSpinner(AdmRowOvrdState)) && <Skeleton height='36px' /> ||
<div className='form__form-group-field'>
<DropdownField
name='cRowAuthId238'
onChange={this.DropdownChange(setFieldValue, setFieldTouched, 'cRowAuthId238')}
value={values.cRowAuthId238}
options={RowAuthId238List}
placeholder=''
disabled = {(authCol.RowAuthId238 || {}).readonly ? 'disabled': '' }/>
</div>
}
{errors.cRowAuthId238 && touched.cRowAuthId238 && <span className='form__form-group-error'>{errors.cRowAuthId238}</span>}
</div>
</Col>
}
{(authCol.AllowSel238 || {}).visible &&
 <Col lg={6} xl={6}>
<div className='form__form-group'>
{(true && this.constructor.ShowSpinner(AdmRowOvrdState)) && <Skeleton height='20px' /> ||
<label className='form__form-group-label'>{(columnLabel.AllowSel238 || {}).ColumnHeader} <span className='text-danger'>*</span>{(columnLabel.AllowSel238 || {}).ToolTip && 
 (<ControlledPopover id={(columnLabel.AllowSel238 || {}).ColumnName} className='sticky-icon pt-0 lh-23' message= {(columnLabel.AllowSel238 || {}).ToolTip} />
)}
</label>
}
{(true && this.constructor.ShowSpinner(AdmRowOvrdState)) && <Skeleton height='36px' /> ||
<div className='form__form-group-field'>
<DropdownField
name='cAllowSel238'
onChange={this.DropdownChange(setFieldValue, setFieldTouched, 'cAllowSel238')}
value={values.cAllowSel238}
options={AllowSel238List}
placeholder=''
disabled = {(authCol.AllowSel238 || {}).readonly ? 'disabled': '' }/>
</div>
}
{errors.cAllowSel238 && touched.cAllowSel238 && <span className='form__form-group-error'>{errors.cAllowSel238}</span>}
</div>
</Col>
}
{(authCol.AllowAdd238 || {}).visible &&
 <Col lg={12} xl={12}>
<div className='form__form-group'>
<label className='checkbox-btn checkbox-btn--colored-click'>
<Field
className='checkbox-btn__checkbox'
type='checkbox'
name='cAllowAdd238'
onChange={handleChange}
defaultChecked={values.cAllowAdd238}
disabled={(authCol.AllowAdd238 || {}).readonly || !(authCol.AllowAdd238 || {}).visible}
/>
<span className='checkbox-btn__checkbox-custom'><CheckIcon /></span>
<span className='checkbox-btn__label'>{(columnLabel.AllowAdd238 || {}).ColumnHeader}</span>
</label>
{(columnLabel.AllowAdd238 || {}).ToolTip && 
 (<ControlledPopover id={(columnLabel.AllowAdd238 || {}).ColumnName} className='sticky-icon pt-0 lh-23' message= {(columnLabel.AllowAdd238 || {}).ToolTip} />
)}
</div>
</Col>
}
{(authCol.AllowUpd238 || {}).visible &&
 <Col lg={12} xl={12}>
<div className='form__form-group'>
<label className='checkbox-btn checkbox-btn--colored-click'>
<Field
className='checkbox-btn__checkbox'
type='checkbox'
name='cAllowUpd238'
onChange={handleChange}
defaultChecked={values.cAllowUpd238}
disabled={(authCol.AllowUpd238 || {}).readonly || !(authCol.AllowUpd238 || {}).visible}
/>
<span className='checkbox-btn__checkbox-custom'><CheckIcon /></span>
<span className='checkbox-btn__label'>{(columnLabel.AllowUpd238 || {}).ColumnHeader}</span>
</label>
{(columnLabel.AllowUpd238 || {}).ToolTip && 
 (<ControlledPopover id={(columnLabel.AllowUpd238 || {}).ColumnName} className='sticky-icon pt-0 lh-23' message= {(columnLabel.AllowUpd238 || {}).ToolTip} />
)}
</div>
</Col>
}
{(authCol.AllowDel238 || {}).visible &&
 <Col lg={12} xl={12}>
<div className='form__form-group'>
<label className='checkbox-btn checkbox-btn--colored-click'>
<Field
className='checkbox-btn__checkbox'
type='checkbox'
name='cAllowDel238'
onChange={handleChange}
defaultChecked={values.cAllowDel238}
disabled={(authCol.AllowDel238 || {}).readonly || !(authCol.AllowDel238 || {}).visible}
/>
<span className='checkbox-btn__checkbox-custom'><CheckIcon /></span>
<span className='checkbox-btn__label'>{(columnLabel.AllowDel238 || {}).ColumnHeader}</span>
</label>
{(columnLabel.AllowDel238 || {}).ToolTip && 
 (<ControlledPopover id={(columnLabel.AllowDel238 || {}).ColumnName} className='sticky-icon pt-0 lh-23' message= {(columnLabel.AllowDel238 || {}).ToolTip} />
)}
</div>
</Col>
}
                            </Row>
                          </div>
                          <div className='form__form-group mart-5 mb-0'>
                            <Row className='btn-bottom-row'>
                              {useMobileView && <Col xs={3} sm={2} className='btn-bottom-column'>
                                <Button color='success' className='btn btn-outline-success account__btn' onClick={this.props.history.goBack} outline><i className='fa fa-long-arrow-left'></i></Button>
                              </Col>}
                              <Col
                                xs={useMobileView ? 9 : 12}
                                sm={useMobileView ? 10 : 12}>
                                <Row>
                                  {
                                    bottomButtonList
                                      .filter(v => v.expose)
                                      .map((v, i, a) => {
                                        if (this.ActionSuppressed(authRow, v.buttonType, (currMst || {}).RowOvrdId238)) return null;
                                        const buttonCount = a.length - a.filter(x => this.ActionSuppressed(authRow, x.buttonType, (currMst || {}).RowOvrdId238));
                                        const colWidth = parseInt(12 / buttonCount, 10);
                                        const lastBtn = i === (a.length - 1);
                                        const outlineProperty = lastBtn ? false : true;
                                        return (
                                          <Col key={v.tid || v.order} xs={colWidth} sm={colWidth} className='btn-bottom-column' >
                                            {this.constructor.ShowSpinner(AdmRowOvrdState) && <Skeleton height='43px' /> ||
                                              <Button color='success' type='button' outline={outlineProperty} className='account__btn' disabled={isSubmitting} onClick={this.ScreenButtonAction[v.buttonType]({ naviBar, submitForm, ScreenButton: v, mst: currMst, useMobileView })}>{v.label}</Button>
                                            }
                                          </Col>
                                        )
                                      })
                                  }
                                </Row>
                              </Col>
                            </Row>
                          </div>
                        </Form>
                      </div>
                    )}
                />
              </div>
            </div>
          </div>
        </div>
      </DocumentTitle>
    );
  };
};

const mapStateToProps = (state) => ({
  user: (state.auth || {}).user,
  error: state.error,
  AdmRowOvrd: state.AdmRowOvrd,
  global: state.global,
});

const mapDispatchToProps = (dispatch) => (
  bindActionCreators(Object.assign({},
    { LoadPage: AdmRowOvrdReduxObj.LoadPage.bind(AdmRowOvrdReduxObj) },
    { SavePage: AdmRowOvrdReduxObj.SavePage.bind(AdmRowOvrdReduxObj) },
    { DelMst: AdmRowOvrdReduxObj.DelMst.bind(AdmRowOvrdReduxObj) },
    { AddMst: AdmRowOvrdReduxObj.AddMst.bind(AdmRowOvrdReduxObj) },
//    { SearchMemberId64: AdmRowOvrdReduxObj.SearchActions.SearchMemberId64.bind(AdmRowOvrdReduxObj) },
//    { SearchCurrencyId64: AdmRowOvrdReduxObj.SearchActions.SearchCurrencyId64.bind(AdmRowOvrdReduxObj) },
//    { SearchCustomerJobId64: AdmRowOvrdReduxObj.SearchActions.SearchCustomerJobId64.bind(AdmRowOvrdReduxObj) },
{ SearchScreenId238: AdmRowOvrdReduxObj.SearchActions.SearchScreenId238.bind(AdmRowOvrdReduxObj) },
{ SearchReportId238: AdmRowOvrdReduxObj.SearchActions.SearchReportId238.bind(AdmRowOvrdReduxObj) },
    { showNotification: showNotification },
    { setTitle: setTitle },
    { setSpinner: setSpinner },
  ), dispatch)
)

export default connect(mapStateToProps, mapDispatchToProps)(MstRecord);

            